<header class="header black-bg">

  <!--logo start-->
  <a class="logo"><b>WEB<span>CAR</span></b></a>
  <!--logo end-->

  <div class="top-menu">
    <ul class="nav pull-right top-menu">
      <li><a class="logout" href="?c=Register&m=createAkun">Register</a></li>
    </ul>
  </div>
  <div class="top-menu">
    <ul class="nav pull-right top-menu">
      <li><a class="logout" href="?c=Login">Login</a></li>
    </ul>
  </div>

</header>